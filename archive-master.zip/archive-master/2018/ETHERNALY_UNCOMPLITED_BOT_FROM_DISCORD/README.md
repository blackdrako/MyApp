# ETHERNALY_UNCOMPLITED_BOT_FROM_DISCORD
Бот с кучей бесполезных команд написанный при помощи библиотеки Discord.js
Документация тут - https://discord.js.org/#/docs/main/stable/general/welcome

Установка:
1. Установить NodeJS (https://nodejs.org/)
2. В менеджере пакетов npm установить пакеты Discord.js и Opusscript 
    ```javascript
        npm install discord.js opusscript
    ```
