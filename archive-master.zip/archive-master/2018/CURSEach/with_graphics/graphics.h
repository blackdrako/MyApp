#ifndef GRAPH_H_
#define  GRAPH_H_
#include <graphics.h>
#include "point.h"
void print_poly(Line * arr,unsigned size);
#endif
