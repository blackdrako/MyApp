#include <stdlib.h>
#include <stdio.h>
#include "task.h"

int main(){
    print_consequences(read_permise(3));
    return 1;
}
