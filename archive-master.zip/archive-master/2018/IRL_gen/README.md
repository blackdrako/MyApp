# IRL_gen
Image Rele Logic Generator
---
  Построение изображения релейно-контактной схемы по СДНФ.
