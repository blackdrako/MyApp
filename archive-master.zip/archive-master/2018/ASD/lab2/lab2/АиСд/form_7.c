#include "form_7.h"
#include <stdlib.h>
#include <stdio.h>

void InitStr(string1 st, unsigned n);{
    st = (string1*) malloc(sizeof(string1);
    st->s = (char*) malloc(n);
    st->max = n;
    st->s=(unsigned short)0;
}

void WriteToStr(string1 st, char *s);{
  int i=0;
  j=(unsigned short*)st.[0];
  while(s[i]!='/0'){
      st[j]=s[i];
      j++;
      i++;
  }

}
