#ifndef DGEN
#define DGEN
int* sorted_arrGen(int size);
int* random_arrGen(int size);
int* sorted_RarrGen(int size);
int* init_arr(int size);
void write_arr(int* arr,int size);
#endif
