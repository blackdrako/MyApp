#ifndef SORT
#define  SORT
void swap(int *a,int *b);
void SelSort(int* A,int nn);
void BSort(int* A,int nn);
void InsSort(int* A,int nn);
void ShellSort(int *mass,int n);

void QSort(int *a, int L, int R);
void HoarSort(int *a, int n);
void ba1Sort(int *array, unsigned n);
void ba2Sort(int *array, unsigned n);

void Sift(int *array, int left, int right);
void HeapSort(int *array, unsigned n);

#endif
