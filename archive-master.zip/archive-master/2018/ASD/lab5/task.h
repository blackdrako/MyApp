#ifndef TASK_H_
#define TASK_H_
#include "list.h"

    list* str_to_list(char* str);
    list* sum_poly(list* poly1,list* poly2);
    void print_poly(list* polynom);
#endif
