#include <stdio.h>
#include <string.h>
int cross_printf(char* format,...);
int cross_fprintf(FILE *file,char* format,...);
char* cross_str(unsigned char* str);
char* cross_str_CP866(unsigned char* str);
