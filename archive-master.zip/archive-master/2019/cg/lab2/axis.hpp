#include <QtMath>
#include <QVector>
#include <QPainter>
#include <algorithm>
#pragma once 

