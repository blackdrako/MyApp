#include <QtWidgets>

int main(int argc, char *argv[]){
    QApplication a(argc, argv);
    return a.exec();
}